package com.ronexio.mobile

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private val prefs by lazy { getSharedPreferences("ronexio_store_v2", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(40, 105, 159)
        window.navigationBarColor = Color.rgb(25, 58, 82)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(230, 237, 242))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(RonexioBridge(), "RonexioNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?) =
                request?.url?.let { assetLoader.shouldInterceptRequest(it) }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.host == "appassets.androidplatform.net") {
                    false
                } else {
                    openSafeWebUrl(uri.toString())
                    true
                }
            }
        }
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)

        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private inner class RonexioBridge {
        @JavascriptInterface
        fun getItem(key: String): String? {
            if (!key.startsWith("ronexio_")) return null
            return prefs.getString(key, null)
        }

        @JavascriptInterface
        fun setItem(key: String, value: String) {
            if (!key.startsWith("ronexio_") || value.length > 1_000_000) return
            prefs.edit().putString(key, value).apply()
        }

        @JavascriptInterface
        fun removeItem(key: String) {
            if (!key.startsWith("ronexio_")) return
            prefs.edit().remove(key).apply()
        }

        @JavascriptInterface
        fun playExperience(placeId: String) {
            if (!placeId.matches(Regex("[0-9]{1,20}"))) {
                runOnUiThread { toast("That Roblox place ID is invalid.") }
                return
            }
            runOnUiThread { launchRobloxExperience(placeId) }
        }

        @JavascriptInterface
        fun openOfficialRoblox() {
            runOnUiThread { launchRobloxApp() }
        }

        @JavascriptInterface
        fun openRobloxUrl(rawUrl: String) {
            runOnUiThread { openSafeWebUrl(rawUrl) }
        }
    }

    private fun launchRobloxExperience(placeId: String) {
        val direct = Intent(Intent.ACTION_VIEW, Uri.parse("roblox://placeId=$placeId")).apply {
            setPackage("com.roblox.client")
        }
        try {
            startActivity(direct)
        } catch (_: Exception) {
            val webStart = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.roblox.com/games/start?placeId=$placeId")
            )
            try {
                startActivity(webStart)
            } catch (_: Exception) {
                toast("Install or update the official Roblox app to play this experience.")
            }
        }
    }

    private fun launchRobloxApp() {
        val launch = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (launch != null) {
            try {
                startActivity(launch)
            } catch (_: Exception) {
                openSafeWebUrl("https://www.roblox.com/home")
            }
        } else {
            toast("The official Roblox app is not installed. Opening Roblox on the web.")
            openSafeWebUrl("https://www.roblox.com/home")
        }
    }

    private fun openSafeWebUrl(rawUrl: String) {
        val uri = try { Uri.parse(rawUrl) } catch (_: Exception) { return }
        val allowed = uri.scheme == "https" &&
            (uri.host == "www.roblox.com" || uri.host == "roblox.com" || uri.host == "create.roblox.com")
        if (!allowed) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            toast("Couldn't open that Roblox page.")
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("RonexioNative")
            webView.destroy()
        }
        super.onDestroy()
    }
}
