# Ronexio Android Project — 1.1.2

Ronexio is an independent, 2013-inspired Android companion launcher. It is **not** a Roblox revival client and does not bundle, patch, or replace Roblox's official app.

## What changed in 1.1.2

- Fixed the login/sign-up crash: the auth handler called `enterApp()` after a valid profile sign-in, but that function was missing. It now hides the auth screen, shows the app shell, and renders Home.
- Updated the Android version to 1.1.2 (versionCode 3).

## Earlier changes in 1.1.0

- Replaced the old `file://` WebView origin with AndroidX `WebViewAssetLoader` at `https://appassets.androidplatform.net/`. This gives the bundled app page a consistent origin for Web APIs and browser storage.
- Added a native Android `SharedPreferences` storage bridge for Ronexio's local profile/session/avatar settings. Browser `localStorage` is still used as a fallback for standalone preview.
- Kept Ronexio sign-up and sign-in separate from Roblox authentication. Ronexio never requests or stores a Roblox password.
- Replaced the old fake 1,000,000 balance with an official-Roblox handoff. Real Robux balances and purchases are handled by Roblox, not by Ronexio.
- Added the five requested tabs: **Home, Discovery, Avatar, Messages, Settings**.
- Added real experience handoff for Brookhaven RP, Adopt Me!, Dress To Impress, and Natural Disaster Survival, plus custom numeric Place ID launching.
- In the Android APK only, the native bridge opens the official Roblox app with Roblox's documented `roblox://placeId=<id>` deep-link pattern. It falls back to Roblox's official web start URL when the deep link cannot be resolved.
- Added local avatar preview customization, local app notices, theme setting, profile logout, and local profile deletion.

## Important limitations

- **Ronexio login** creates a local profile on this device. It is not an online Ronexio account service. Android app storage is persisted with SharedPreferences; standalone browser preview uses browser storage.
- **Roblox sign-in** must happen inside the official Roblox app or official Roblox website. Ronexio does not collect Roblox credentials.
- **Real Robux** is never fabricated or edited by Ronexio. The app opens Roblox so the user can check the genuine balance and use Roblox's own purchase flows. The app does not implement Robux transfers or purchases.
- **Games** run in the installed official Roblox Android app. Ronexio does not contain Roblox's proprietary game engine/client, copy game assets, or emulate its servers. Game launching is APK-only because it uses the Android native bridge; the web preview intentionally cannot launch games.
- The Messages tab contains Ronexio-local notices and a link to the official Roblox inbox. It does not read Roblox private messages.
- The Avatar tab is a local preview and does not change the Roblox account avatar.
- The app does not yet provide a cloud account service, OAuth-based Roblox account linking, online Ronexio messaging, matchmaking, or its own multiplayer runtime.

## Build a real Android APK

1. Install Android Studio and the Android SDK (API 35).
2. Open this `Ronexio` folder as an Android Studio project.
3. Allow Gradle sync. The project uses Android Gradle Plugin 8.7.3, Kotlin Android plugin 2.0.21, and `androidx.webkit:webkit:1.18.0`.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.

Minimum Android version: Android 7.0 (API 24). Target SDK: 35.

## Roblox app requirement

Install/update the official Roblox Android app separately. In Ronexio's Discovery tab, select **PLAY IN ROBLOX**. The official app must be installed and able to open Roblox experience deep links.
